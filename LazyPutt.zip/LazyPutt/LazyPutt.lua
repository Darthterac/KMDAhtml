-- ============================================================
-- LazyPutt.lua
-- Vector-Based Putting Physics
--
-- Direction is represented by a normalized X/Y vector instead of
-- repeatedly converting between vectors and angles.
-- ============================================================

local PuttingGameBoardGlobal = nil

local function CreatePuttingGame()
    if PuttingGameBoardGlobal then
        PuttingGameBoardGlobal:Show()
        return
    end

    -- ============================================================
    -- 1. Main Game Board
    -- ============================================================

    local board = CreateFrame(
        "Button",
        "WoWPuttingBoard",
        UIParent,
        "BackdropTemplate"
    )

    board:SetSize(400, 400)
    board:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    board:EnableMouse(true)

    board:SetBackdrop({
        bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 16,
        insets = {
            left = 4,
            right = 4,
            top = 4,
            bottom = 4
        }
    })

    board:SetBackdropColor(0.1, 0.5, 0.2, 0.8)

    PuttingGameBoardGlobal = board

    -- Make Frame Draggable
    board:SetMovable(true)
    board:RegisterForDrag("LeftButton")

    board:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)

    board:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)

    -- ============================================================
    -- Close Button
    -- ============================================================

    local closeButton = CreateFrame(
        "Button",
        nil,
        board,
        "UIPanelCloseButton"
    )

    closeButton:SetPoint(
        "TOPRIGHT",
        board,
        "TOPRIGHT",
        -4,
        -4
    )

    closeButton:SetFrameLevel(board:GetFrameLevel() + 10)

    closeButton:SetScript("OnClick", function()
        board:SetScript("OnUpdate", nil)
        board:Hide()

        print("|cffffee00LazyPutt Hidden! Type /putt to bring it back.|r")
    end)

    -- ============================================================
    -- 2. Score Tracker
    -- ============================================================

    local scoreTrack = board:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalLarge"
    )

    scoreTrack:SetPoint(
        "TOPLEFT",
        board,
        "TOPLEFT",
        15,
        -15
    )

    scoreTrack:SetTextColor(1, 1, 1, 1)

    local strokes = 0

    local function UpdateScoreDisplay()
        scoreTrack:SetText(
            string.format(
                "Strokes: |cffffee00%d|r",
                strokes
            )
        )
    end

    UpdateScoreDisplay()

    -- ============================================================
    -- 3. Flag & Hole Layout
    -- ============================================================

    local holeX, holeY = 110, 100 
    local ballX, ballY = -120, -100 

    local hole = board:CreateTexture(nil, "ARTWORK")
    hole:SetTexture(6116532)
    hole:SetSize(20, 20)

    local flagpole = board:CreateTexture(nil, "OVERLAY")
    flagpole:SetColorTexture(0.8, 0.8, 0.8, 1)
    flagpole:SetSize(4, 69)

    local flagCloth = board:CreateTexture(nil, "OVERLAY")
    flagCloth:SetColorTexture(1, 0.15, 0.05, 0.95)
    flagCloth:SetSize(21, 14)

    flagCloth:SetPoint(
        "TOPRIGHT",
        flagpole,
        "TOPLEFT",
        0,
        -1
    )

    local function MoveHoleToTopRight()
        local randomX = math.random(-80, 145)
        local randomY = math.random(-70, 145)

        holeX = randomX
        holeY = randomY

        hole:SetPoint(
            "CENTER",
            board,
            "CENTER",
            holeX,
            holeY
        )

        flagpole:SetPoint(
            "BOTTOM",
            board,
            "CENTER",
            holeX,
            holeY
        )
    end

    MoveHoleToTopRight()

    -- ============================================================
    -- 4. Advanced 3D Sphere Construction
    -- ============================================================

    local ball = CreateFrame(
        "Button",
        nil,
        board,
        "BackdropTemplate"
    )

    ball:SetSize(22, 22)

    ball:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = true,
        tileSize = 2,
        edgeSize = 2,
        insets = {
            left = -1,
            right = -1,
            top = -1,
            bottom = -1
        }
    })

    ball:SetBackdropColor(0, 0, 0, 0)
    ball:SetBackdropBorderColor(0, 0, 0, 0)

    ball:SetFrameLevel(board:GetFrameLevel() + 5)
    ball:EnableMouse(true)

    local ballPattern = ball:CreateTexture(nil, "ARTWORK")
    ballPattern:SetTexture(518448)
    ballPattern:SetVertexColor(1, 0.85, 0, 1)
    ballPattern:SetAllPoints()

    local ballStripe = ball:CreateTexture(nil, "ARTWORK")
    ballStripe:SetTexture(518451)
    ballStripe:SetVertexColor(1, 1, 1, 1)
    ballStripe:SetPoint(
        "CENTER",
        ball,
        "CENTER",
        0,
        0
    )

    local ballShadow = ball:CreateTexture(nil, "ARTWORK")
    ballShadow:SetTexture(4952341)
    ballShadow:SetVertexColor(0, 0, 0, 0.45)
    ballShadow:SetSize(20, 1)

    ballShadow:SetPoint(
        "CENTER",
        ball,
        "CENTER",
        0,
        -10
    )

    local currentRotation = 0

    local function ResetBall()
        ballX =  math.random(-70, 145) --120 
        ballY =  math.random(-60, 145) --100

        ball:SetPoint(
            "CENTER",
            board,
            "CENTER",
            ballX,
            ballY
        )

        currentRotation = 0

        ballPattern:SetRotation(0)
        ballStripe:SetRotation(0)
    end

    ResetBall()

    -- ============================================================
    -- 5. Dynamic Shot Power Bar
    -- ============================================================

    local powerBG = board:CreateTexture(nil, "BACKGROUND")
    powerBG:SetColorTexture(0, 0, 0, 0.5)
    powerBG:SetSize(12, 160)

    powerBG:SetPoint(
        "LEFT",
        board,
        "LEFT",
        15,
        0
    )

    local powerFill = board:CreateTexture(nil, "ARTWORK")
    powerFill:SetColorTexture(0, 1, 0, 1)
    powerFill:SetWidth(12)

    powerFill:SetPoint(
        "BOTTOM",
        powerBG,
        "BOTTOM",
        0,
        0
    )

    powerFill:SetHeight(0)

    -- ============================================================
    -- 6. Aim Prediction Line
    -- ============================================================

    local aimLine = board:CreateLine(nil, "OVERLAY")
    aimLine:SetThickness(3)
    aimLine:Hide()

    -- ============================================================
    -- 7. Game State
    -- ============================================================

    local isCharging = false
    local chargePower = 0

    local maxPower = 400
    local ballSpeed = 0
    local friction = 110

    -- ============================================================
    -- 8. Direction Vector State
    --
    -- shotDirX / shotDirY always represent the current normalized
    -- direction of travel.
    -- ============================================================

    local shotDirX = 0
    local shotDirY = 0

    -- Warp state
    local warpCenterX = math.random(-60, 60)
    local warpCenterY = math.random(-60, 60)

    local warpStrength = 85

    -- ============================================================
    -- 9. Vector Helpers
    -- ============================================================

    local function NormalizeVector(x, y)
        local length = math.sqrt(x * x + y * y)

        if length < 0.0001 then
            return 0, 0
        end

        return x / length, y / length
    end

    local function GetMouseBoardPosition()
        local mouseX, mouseY = GetCursorPosition()
        local scale = board:GetEffectiveScale()

        mouseX = mouseX / scale
        mouseY = mouseY / scale

        local boardLeft = board:GetLeft() or 0
        local boardBottom = board:GetBottom() or 0

        local boardMouseX = mouseX - boardLeft
        local boardMouseY = mouseY - boardBottom

        local centerX = board:GetWidth() / 2
        local centerY = board:GetHeight() / 2

        return (
            boardMouseX - centerX
        ), (
            boardMouseY - centerY
        )
    end

    -- ============================================================
    -- 10. Get Shot Direction
    --
    -- The ball travels AWAY from the cursor.
    --
    -- Instead of calculating an angle, we calculate the vector:
    --
    --     Ball - Cursor
    --
    -- and normalize it.
    -- ============================================================

    local function GetShotDirection()
        local mouseX, mouseY = GetMouseBoardPosition()

        local dx = ballX - mouseX
        local dy = ballY - mouseY

        return NormalizeVector(dx, dy)
    end

    -- ============================================================
    -- 11. Aim Line
    -- ============================================================

    local function UpdateAimLine(length)
        local endX =
            ballX + (length * shotDirX)

        local endY =
            ballY + (length * shotDirY)

        aimLine:SetStartPoint(
            "CENTER",
            ball,
            0,
            0
        )

        aimLine:SetEndPoint(
            "CENTER",
            board,
            endX,
            endY
        )
    end

    -- ============================================================
    -- 12. Hover Cue Scanner
    -- ============================================================

    ball:SetScript("OnUpdate", function(self, elapsed)
        if ballSpeed > 0 or isCharging then
            return
        end

        if self:IsMouseOver() then
            shotDirX, shotDirY = GetShotDirection()

            aimLine:SetColorTexture(
                1,
                1,
                1,
                0.75
            )

            aimLine:Show()

            UpdateAimLine(60)
        else
            aimLine:Hide()
        end
    end)

    -- ============================================================
    -- 13. Click and Hold - Build Shot Power
    -- ============================================================

    ball:SetScript("OnMouseDown", function(self, button)
        if ballSpeed > 0 then
            return
        end

        if button ~= "LeftButton" then
            return
        end

        isCharging = true
        chargePower = 0

        powerFill:SetHeight(0)

        shotDirX, shotDirY = GetShotDirection()

        aimLine:SetColorTexture(
            1,
            1,
            0,
            0.7
        )

        board:SetScript("OnUpdate", function(_, elapsed)
            if not isCharging then
                return
            end

            chargePower = math.min(
                chargePower + (250 * elapsed),
                maxPower
            )

            local ratio = chargePower / maxPower

            powerFill:SetHeight(
                160 * ratio
            )

            powerFill:SetVertexColor(
                ratio,
                1 - ratio,
                0
            )

            local lineLength =
                40 + (chargePower * 0.4)

            UpdateAimLine(lineLength)
        end)
    end)

    -- ============================================================
    -- 14. Mouse Release - Launch Physics
    -- ============================================================

    ball:SetScript("OnMouseUp", function(self, button)
        if not isCharging then
            return
        end

        isCharging = false

        aimLine:Hide()
        powerFill:SetHeight(0)

        ballSpeed = chargePower

        strokes = strokes + 1
        UpdateScoreDisplay()

        -- Play hitting sound
        PlaySoundFile(
            "Sound\\Doodad\\G_WoodBench_Destroy01.ogg",
            "Master"
        )

        -- ========================================================
        -- Physics Simulation
        -- ========================================================

        board:SetScript("OnUpdate", function(_, elapsed)
            if ballSpeed <= 0 then
                return
            end

            -- ----------------------------------------------------
            -- Apply Friction
            -- ----------------------------------------------------

            ballSpeed = ballSpeed - (
                friction * elapsed
            )

            if ballSpeed <= 0 then
                ballSpeed = 0
                board:SetScript("OnUpdate", nil)
                return
            end

            -- ----------------------------------------------------
            -- Calculate Warp Vector
            --
            -- The warp center pulls the ball toward itself.
            -- ----------------------------------------------------

            local deltaWarpX =
                warpCenterX - ballX

            local deltaWarpY =
                warpCenterY - ballY

            local distanceToWarp =
                math.sqrt(
                    deltaWarpX * deltaWarpX
                    + deltaWarpY * deltaWarpY
                )

            if distanceToWarp < 150
                and distanceToWarp > 5
            then
                -- Normalize the warp direction.
                local warpDirX =
                    deltaWarpX / distanceToWarp

                local warpDirY =
                    deltaWarpY / distanceToWarp

                -- Warp becomes stronger as the ball gets
                -- closer to the warp center.
                --
                -- The value is intentionally scaled by speed
                -- so the effect remains subtle at high velocity.
                local warpAmount =
                    (1 - (distanceToWarp / 150))
                    * (warpStrength / ballSpeed)
                    * elapsed

                -- ------------------------------------------------
                -- Blend the current travel vector with the
                -- gravitational/warp vector.
                -- ------------------------------------------------

                shotDirX =
                    shotDirX
                    + (warpDirX * warpAmount)

                shotDirY =
                    shotDirY
                    + (warpDirY * warpAmount)

                -- ------------------------------------------------
                -- Normalize again so direction remains a unit
                -- vector after the blend.
                -- ------------------------------------------------

                shotDirX, shotDirY =
                    NormalizeVector(
                        shotDirX,
                        shotDirY
                    )
            end

            -- ----------------------------------------------------
            -- Render Positional Step
            -- ----------------------------------------------------

            local step =
                ballSpeed * elapsed

            ballX =
                ballX
                + (step * shotDirX)

            ballY =
                ballY
                + (step * shotDirY)

            ball:SetPoint(
                "CENTER",
                board,
                "CENTER",
                ballX,
                ballY
            )

            -- ----------------------------------------------------
            -- 3D Rotation Spin Rendering
            -- ----------------------------------------------------

            local rotationStep =
                (ballSpeed / 30) * elapsed

            currentRotation =
                currentRotation + rotationStep

            ballPattern:SetRotation(
                currentRotation
            )

            ballStripe:SetRotation(
                currentRotation + 0.5
            )

            -- ----------------------------------------------------
            -- Wall Bounds Check
            -- ----------------------------------------------------

            if math.abs(ballX) > 190
                or math.abs(ballY) > 190
            then
                ballSpeed = 0
                board:SetScript("OnUpdate", nil)

                print(
                    "|cffff3333Out of Bounds! 🏌️‍♂️ Resetting...|r"
                )

                ResetBall()
                return
            end

            -- ----------------------------------------------------
            -- Check Cup Drop
            -- ----------------------------------------------------

            local distHoleX =
                holeX - ballX

            local distHoleY =
                holeY - ballY

            local distanceToHole =
                math.sqrt(
                    distHoleX * distHoleX
                    + distHoleY * distHoleY
                )

            if distanceToHole < 16 then
                if ballSpeed < 180 then
                    ballSpeed = 0
                    board:SetScript("OnUpdate", nil)

                    ball:SetPoint(
                        "CENTER",
                        board,
                        "CENTER",
                        holeX,
                        holeY
                    )

                    print(
                        string.format(
                            "|cff44ff44SUNK IT IN %d STROKES! ⛳🎉|r",
                            strokes
                        )
                    )

                    -- Play crowd cheering audio
                    PlaySoundFile(
                        "Sound\\Events\\gruntling\\_cheer.ogg",
                        "Master"
                    )

                    C_Timer.After(1.5, function()
                        ResetBall()
                        MoveHoleToTopRight()

                        strokes = 0
                        UpdateScoreDisplay()

                        warpCenterX =
                            math.random(-60, 60)

                        warpCenterY =
                            math.random(-60, 60)

                        print(
                            "|cffffff00Green shifted! A fresh warp layout shape has formed!|r"
                        )
                    end)
                else
                    print(
                        "|cffffee00Too much power! Cruised right over the edge.|r"
                    )
                end
            end
        end)
    end)
end

-- ============================================================
-- Slash Command Registry
-- ============================================================

SLASH_LAZYPUTT1 = "/putt"

SlashCmdList["LAZYPUTT"] = function()
    if not PuttingGameBoardGlobal then
        CreatePuttingGame()
        return
    end

    if PuttingGameBoardGlobal:IsShown() then
        PuttingGameBoardGlobal:Hide()
    else
        PuttingGameBoardGlobal:Show()
    end
end

-- ============================================================
-- Launch Addon Window On Initial UI Loading
-- ============================================================

CreatePuttingGame()
